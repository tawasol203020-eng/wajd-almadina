# موقع وجد المدينة - WAJD ALMADINA Website

موقع رسمي لمؤسسة وجد المدينة للمقاولات والتشييد - المملكة العربية السعودية.

---

## محتويات الحزمة

```
wajdmed_site/
├── index.html              ← الصفحة الرئيسية
├── 404.html                ← صفحة الخطأ
├── robots.txt              ← لمحركات البحث
├── sitemap.xml             ← خريطة الموقع
├── README.md               ← هذا الملف
└── assets/
    └── images/             ← جميع الصور (2.4 MB)
        ├── logo.png
        ├── favicon.ico
        ├── hero-bg.jpg
        ├── og-image.jpg    ← صورة المشاركة على السوشيال
        └── ...
```

---

## ✅ جاهز للنشر مباشرة

الموقع **standalone بالكامل**:
- ✓ HTML/CSS/JavaScript واحد
- ✓ لا يحتاج Node.js أو خادم خاص
- ✓ لا يحتاج قاعدة بيانات
- ✓ يشتغل على أي استضافة ثابتة
- ✓ متجاوب (موبايل، تابلت، كمبيوتر)
- ✓ Meta tags كاملة لـ SEO
- ✓ Open Graph للمشاركة على فيسبوك/تويتر
- ✓ Schema.org structured data
- ✓ خط عربي وإنجليزي
- ✓ زر WhatsApp ثابت

---

## طرق النشر (مرتبة من الأسهل)

### الطريقة 1: استضافة عادية (cPanel)
1. سجل دخول للـ cPanel
2. افتح **File Manager**
3. اذهب لمجلد `public_html`
4. ارفع جميع محتويات هذا المجلد (index.html، assets، إلخ)
5. ✅ الموقع مباشر على دومينك

### الطريقة 2: Cloudflare Pages (مجاناً)
1. اذهب لـ https://pages.cloudflare.com
2. سجل دخول وأنشئ مشروع جديد
3. اختر "Direct Upload"
4. اسحب وأفلت مجلد `wajdmed_site` بأكمله
5. اربطه بدومينك `wajdmed.com`

### الطريقة 3: GitHub Pages (مجاناً)
1. أنشئ repo جديد على GitHub باسم `wajdmed.github.io`
2. ارفع جميع الملفات
3. Settings → Pages → Source: main branch
4. الموقع جاهز على `https://wajdmed.github.io`

### الطريقة 4: Netlify (مجاناً)
1. اذهب لـ https://app.netlify.com/drop
2. اسحب وأفلت مجلد `wajdmed_site`
3. الموقع مباشر بدومين مجاني، يمكن ربطه بدومينك

### الطريقة 5: استضافة سعودية (Hostinger، GoDaddy، إلخ)
نفس طريقة cPanel - ارفع الملفات لمجلد `public_html` أو `www`.

---

## ربط الدومين wajdmed.com

بعد رفع الملفات، تأكد من:
1. **A Record** يشير لـ IP الاستضافة
2. **CNAME** للـ www يشير للدومين الأساسي
3. تفعيل **SSL** (HTTPS) — معظم الاستضافات تفعّله مجاناً
4. تأكد أن `https://wajdmed.com` و `https://www.wajdmed.com` يفتحان الموقع

---

## تخصيصات بسيطة

### تغيير رقم الواتساب
ابحث في `index.html` عن:
```html
href="https://wa.me/966552007372"
```
واستبدل الرقم.

### تغيير صورة Hero
استبدل ملف `assets/images/hero-bg.jpg` بصورة جديدة (نفس الاسم).

### تغيير ألوان الهوية
في بداية `<style>` في index.html:
```css
--navy: #0F1B3F;     /* اللون الكحلي */
--gold: #B38E4E;     /* اللون الذهبي */
```

### إضافة Google Analytics
أضف قبل `</head>` في index.html:
```html
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXX');
</script>
```

---

## بعد النشر - مهم

1. **Google Search Console**: سجّل الموقع وارفع `sitemap.xml`
2. **Google Business Profile**: أنشئ ملف للنشاط التجاري
3. **اختبر الموقع** على:
   - https://pagespeed.web.dev (قياس السرعة)
   - https://search.google.com/test/mobile-friendly (التوافق مع الموبايل)
   - https://developers.facebook.com/tools/debug (لمعاينة Open Graph)

---

## معلومات تقنية

- **حجم الموقع**: ~2.5 MB إجمالي
- **عدد الصور**: 21 صورة محسّنة للويب
- **التحميل**: ~1-2 ثانية على اتصال 4G
- **التوافق**: جميع المتصفحات الحديثة (Chrome, Safari, Firefox, Edge)
- **Mobile**: متجاوب بالكامل من 320px فأكثر

---

## للدعم الفني

إذا احتجت تعديلات أو مساعدة في النشر، تواصل مع المطور.

**موقع وجد المدينة © 2026**
